clc, clear all;
Regresion(3, 50);

fprintf('*****************VecinosCercanos*****************\n');
VecinosCercanos(3);